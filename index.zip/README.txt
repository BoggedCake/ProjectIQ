HomeProjectIQ Northern Beaches Tester V6.0

Netlify-ready drag-and-drop package.

FILES
- index.html
- netlify.toml
- _headers
- README.txt
- QA_REPORT.txt

EXTERNAL DATASETS / SERVICES
- ArcGIS World Geocoder: fast address suggestions and selected-address coordinates
- NSW Spatial Services: NSW Address Point Formatted layer
- NSW Land Parcel Property Theme: cadastral parcel / lot geometry
- NSW Planning Portal Principal Planning service: zoning, height, FSR, minimum lot, heritage, foreshore
- NSW Planning Portal Hazard service: bushfire and flood mapping
- NSW Planning Portal SEPP service: indicative Housing SEPP / LMR screening
- Northern Beaches Council context is shown as contextual guidance; statutory NSW planning layers remain the primary mapped source in the beta

PROJECTIQ WORKING VALUE
The beta working range uses Northern Beaches suburb benchmarks, a regional fallback, property type, land size, bedrooms, bathrooms and optional owner/agent estimates.
It is not a formal valuation and is not a licensed property-level REA/PropTrack AVM.
REA, Property.com.au and Domain are not scraped or automatically ingested.

DEVELOPMENT PATHWAY
One Develop My Land pathway only:
1. Duplex / dual occupancy
2. Townhouse / terrace
3. Boutique apartment
4. Multi-site development with neighbours

LOWER NORTHERN BEACHES DUPLEX GRV REFERENCES
The premium/luxury duplex beta logic uses:
- 25 Nield Avenue, Balgowlah: approx. $5.26m per dwelling
- 102 Condamine Street, Balgowlah: approx. $4.0m per dwelling
- 150A Woodland Street, Balgowlah: approx. $3.85m per dwelling

LIMITATIONS
- LMR is an indicative screen, not a legal walking-distance determination.
- Point-based mapped overlay checks are not a substitute for parcel-wide professional assessment.
- Frontage is indicative, not survey verified.
- Development feasibility is early-stage decision support, not a QS estimate, formal valuation or approval guarantee.
- Finance/holding assumptions remain provisional until broker inputs are supplied.

See QA_REPORT.txt for the architecture audit and exact regression tests completed.

V6.1 fixes:
- Removed the legacy duplex comparison panel and replaced it with the agreed Lower Northern Beaches luxury evidence set.
- Duplex evidence now shows 25 Nield Ave, 102 Condamine St and 150A Woodland St only.
- Principal planning controls now query in GDA94 / EPSG:4283.
- Added a MapServer identify fallback for zone, LEP, height, FSR, minimum lot size, heritage and foreshore when individual layer queries return blank.
- Planning parsing now follows the current official NSW Planning Portal field schemas.

V6.2:
- Duplex project range tightened to approximately 30% total spread around the selected base case.
- Product selections continue to move the duplex base cost.
- White KPI boxes now use dark high-contrast text.
- Planning controls retry against the cadastral parcel polygon when point lookup misses, before MapServer identify fallback.
- Unconfirmed planning fields say 'Not automatically confirmed' rather than showing a bare dash.
- Decision Gate buttons fixed: Continue -> Roadmap; Reduce Scope -> Scope editor; Compare Alternatives -> Stay vs Move.
- Boyle Street remains removed.

V6.3 Voice Brief Beta:
- Adds a Talk It Through / Type It Instead brief immediately after the property step.
- User sees a structured “Here’s what I understood” confirmation before assumptions are applied.
- Plain-English beta parser recognises direction, scope, budget, finish and duplex features.
- Accepted brief pre-fills the existing ProjectIQ scope workflow.
- Browser SpeechRecognition is used where supported; unsupported browsers fall back to keyboard dictation/manual typing.
- Manual project selection remains available.
- Broker/finance module is intentionally unchanged pending finance assumptions.
